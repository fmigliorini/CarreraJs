$(function(){
	$("#game").damas();
});